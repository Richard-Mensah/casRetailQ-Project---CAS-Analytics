import React, { createContext, useContext, useState, useEffect } from 'react';
import { Sale, Expense, InventoryItem, Supplier, Customer, Alert, BusinessProfile } from '../types';
import { seedSales, seedExpenses, seedInventory, seedSuppliers, seedCustomers, seedAlerts } from '../data/seed';

interface AppContextType {
  // Data
  sales: Sale[];
  expenses: Expense[];
  inventory: InventoryItem[];
  suppliers: Supplier[];
  customers: Customer[];
  alerts: Alert[];
  profile: BusinessProfile;
  // Actions
  addSale: (s: Omit<Sale,'id'>) => void;
  addExpense: (e: Omit<Expense,'id'>) => void;
  addInventoryItem: (i: Omit<InventoryItem,'id'>) => void;
  updateInventoryItem: (id: string, updates: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  addSupplier: (s: Omit<Supplier,'id'>) => void;
  addCustomer: (c: Omit<Customer,'id'>) => void;
  markAlertRead: (id: string) => void;
  markAllAlertsRead: () => void;
  updateProfile: (p: Partial<BusinessProfile>) => void;
  // Computed
  todayRevenue: number;
  weekRevenue: number;
  monthRevenue: number;
  todayExpenses: number;
  monthExpenses: number;
  netProfit: number;
  lowStockItems: InventoryItem[];
  unreadAlerts: number;
}

const AppContext = createContext<AppContextType | null>(null);

const STORAGE_KEYS = {
  sales: 'retailiq_sales',
  expenses: 'retailiq_expenses',
  inventory: 'retailiq_inventory',
  suppliers: 'retailiq_suppliers',
  customers: 'retailiq_customers',
  alerts: 'retailiq_alerts',
  profile: 'retailiq_profile',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch { return fallback; }
}

function saveToStorage(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

function uid() { return Math.random().toString(36).slice(2,10); }

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [sales, setSales]           = useState<Sale[]>(() => loadFromStorage(STORAGE_KEYS.sales, seedSales));
  const [expenses, setExpenses]     = useState<Expense[]>(() => loadFromStorage(STORAGE_KEYS.expenses, seedExpenses));
  const [inventory, setInventory]   = useState<InventoryItem[]>(() => loadFromStorage(STORAGE_KEYS.inventory, seedInventory));
  const [suppliers, setSuppliers]   = useState<Supplier[]>(() => loadFromStorage(STORAGE_KEYS.suppliers, seedSuppliers));
  const [customers, setCustomers]   = useState<Customer[]>(() => loadFromStorage(STORAGE_KEYS.customers, seedCustomers));
  const [alerts, setAlerts]         = useState<Alert[]>(() => loadFromStorage(STORAGE_KEYS.alerts, seedAlerts));
  const [profile, setProfile]       = useState<BusinessProfile>(() => loadFromStorage(STORAGE_KEYS.profile, {
    name: 'Adwuma Pa Provisions',
    owner: 'Akosua Mensah',
    phone: '0244-567890',
    email: 'akosua@adwumapa.gh',
    location: 'Makola Market, Accra',
    businessType: 'Provisions & Grocery',
    currency: 'GHS',
    healthScore: 74,
  }));

  useEffect(() => { saveToStorage(STORAGE_KEYS.sales, sales); }, [sales]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.expenses, expenses); }, [expenses]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.inventory, inventory); }, [inventory]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.suppliers, suppliers); }, [suppliers]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.customers, customers); }, [customers]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.alerts, alerts); }, [alerts]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.profile, profile); }, [profile]);

  const today = new Date().toISOString().split('T')[0];
  const weekAgo = new Date(Date.now() - 7*86400000).toISOString().split('T')[0];
  const monthStart = new Date().toISOString().slice(0,7);

  const todayRevenue   = sales.filter(s => s.date === today).reduce((a,s) => a + s.total, 0);
  const weekRevenue    = sales.filter(s => s.date >= weekAgo).reduce((a,s) => a + s.total, 0);
  const monthRevenue   = sales.filter(s => s.date.startsWith(monthStart)).reduce((a,s) => a + s.total, 0);
  const todayExpenses  = expenses.filter(e => e.date === today).reduce((a,e) => a + e.amount, 0);
  const monthExpenses  = expenses.filter(e => e.date.startsWith(monthStart)).reduce((a,e) => a + e.amount, 0);
  const netProfit      = monthRevenue - monthExpenses;
  const lowStockItems  = inventory.filter(i => i.qty <= i.reorderLevel);
  const unreadAlerts   = alerts.filter(a => !a.read).length;

  const addSale = (s: Omit<Sale,'id'>) => setSales(prev => [{ ...s, id: uid() }, ...prev]);
  const addExpense = (e: Omit<Expense,'id'>) => setExpenses(prev => [{ ...e, id: uid() }, ...prev]);
  const addInventoryItem = (i: Omit<InventoryItem,'id'>) => setInventory(prev => [{ ...i, id: uid() }, ...prev]);
  const updateInventoryItem = (id: string, updates: Partial<InventoryItem>) =>
    setInventory(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
  const deleteInventoryItem = (id: string) => setInventory(prev => prev.filter(i => i.id !== id));
  const addSupplier = (s: Omit<Supplier,'id'>) => setSuppliers(prev => [{ ...s, id: uid() }, ...prev]);
  const addCustomer = (c: Omit<Customer,'id'>) => setCustomers(prev => [{ ...c, id: uid() }, ...prev]);
  const markAlertRead = (id: string) => setAlerts(prev => prev.map(a => a.id === id ? { ...a, read:true } : a));
  const markAllAlertsRead = () => setAlerts(prev => prev.map(a => ({ ...a, read:true })));
  const updateProfile = (p: Partial<BusinessProfile>) => setProfile(prev => ({ ...prev, ...p }));

  return (
    <AppContext.Provider value={{
      sales, expenses, inventory, suppliers, customers, alerts, profile,
      addSale, addExpense, addInventoryItem, updateInventoryItem, deleteInventoryItem,
      addSupplier, addCustomer, markAlertRead, markAllAlertsRead, updateProfile,
      todayRevenue, weekRevenue, monthRevenue, todayExpenses, monthExpenses,
      netProfit, lowStockItems, unreadAlerts,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be inside AppProvider');
  return ctx;
}
