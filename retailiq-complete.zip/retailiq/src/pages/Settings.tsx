import React, { useState } from 'react';
import {
  Settings as SettingsIcon, User, Building, CreditCard,
  Shield, Bell, Save, RefreshCw, Zap, TrendingUp
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function Settings() {
  const { profile, updateProfile } = useApp();
  const [form, setForm] = useState({ ...profile });
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile'|'health'|'data'>('profile');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleReset = () => {
    if (window.confirm('This will clear all data and reload with sample data. Are you sure?')) {
      Object.keys(localStorage).filter(k => k.startsWith('retailiq_')).forEach(k => localStorage.removeItem(k));
      window.location.reload();
    }
  };

  const healthColor = profile.healthScore >= 75 ? '#1D9E75'
    : profile.healthScore >= 50 ? '#BA7517' : '#D85A30';

  const healthLabel = profile.healthScore >= 75 ? 'Excellent'
    : profile.healthScore >= 60 ? 'Good'
    : profile.healthScore >= 40 ? 'Fair' : 'Needs Attention';

  const healthFactors = [
    { label: 'Sales Consistency', score: 82, desc: 'You record sales regularly — great habit!' },
    { label: 'Inventory Management', score: 68, desc: 'A few items are low — restock soon' },
    { label: 'Profit Margin', score: 74, desc: 'Healthy margins on most products' },
    { label: 'Customer Retention', score: 71, desc: '3 VIP customers returning regularly' },
    { label: 'Expense Control', score: 65, desc: 'Stock purchase costs are the biggest expense' },
    { label: 'Payment Diversity', score: 80, desc: 'Good mix of MoMo, cash, and card' },
  ];

  const tabs = [
    { id: 'profile', label: 'Business Profile', icon: User },
    { id: 'health', label: 'Health Score', icon: TrendingUp },
    { id: 'data', label: 'Data & System', icon: Shield },
  ] as const;

  return (
    <div className="p-4 lg:p-6 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#E1F5EE' }}>
          <SettingsIcon size={18} style={{ color: '#1D9E75' }} />
        </div>
        <div>
          <h2 className="font-bold text-gray-900 text-lg">Settings</h2>
          <p className="text-xs text-gray-500">Manage your business profile and preferences</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl w-full overflow-x-auto" style={{ background: '#f1f5f1' }}>
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveTab(id)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all flex-shrink-0"
            style={activeTab === id
              ? { background: '#fff', color: '#1D9E75', boxShadow: '0 1px 3px rgba(0,0,0,.1)' }
              : { color: '#6b7280' }}>
            <Icon size={15} />{label}
          </button>
        ))}
      </div>

      {/* Profile tab */}
      {activeTab === 'profile' && (
        <form onSubmit={handleSave} className="card space-y-5">
          <div className="flex items-center gap-4 pb-4 border-b border-gray-100">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold text-white"
              style={{ background: '#1D9E75' }}>
              {form.name.charAt(0)}
            </div>
            <div>
              <div className="font-bold text-gray-900">{form.name}</div>
              <div className="text-sm text-gray-500">{form.businessType}</div>
              <div className="text-xs text-gray-400 mt-0.5">{form.location}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Business Name *</label>
              <input required className="input-field" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="label">Owner Name *</label>
              <input required className="input-field" value={form.owner}
                onChange={e => setForm({ ...form, owner: e.target.value })} />
            </div>
            <div>
              <label className="label">Phone Number</label>
              <input className="input-field" value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div>
              <label className="label">Email Address</label>
              <input type="email" className="input-field" value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label className="label">Location / Market</label>
              <input className="input-field" value={form.location}
                onChange={e => setForm({ ...form, location: e.target.value })} />
            </div>
            <div>
              <label className="label">Business Type</label>
              <select className="input-field" value={form.businessType}
                onChange={e => setForm({ ...form, businessType: e.target.value })}>
                {['Provisions & Grocery', 'Fashion & Clothing', 'Electronics', 'Pharmaceuticals',
                  'Food & Beverages', 'Hardware', 'Agriculture', 'General Retail'].map(t => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Registration Number</label>
              <input className="input-field" placeholder="GH-BN-XXXXXX"
                value={form.registrationNumber || ''}
                onChange={e => setForm({ ...form, registrationNumber: e.target.value })} />
            </div>
            <div>
              <label className="label">Currency</label>
              <select className="input-field" value={form.currency}
                onChange={e => setForm({ ...form, currency: e.target.value })}>
                <option value="GHS">GHS — Ghanaian Cedi</option>
                <option value="NGN">NGN — Nigerian Naira</option>
                <option value="XOF">XOF — CFA Franc</option>
                <option value="USD">USD — US Dollar</option>
              </select>
            </div>
          </div>

          <button type="submit"
            className="btn-primary"
            style={saved ? { background: '#0F6E56' } : {}}>
            {saved ? <><RefreshCw size={15} /> Saved!</> : <><Save size={15} /> Save Changes</>}
          </button>
        </form>
      )}

      {/* Health Score tab */}
      {activeTab === 'health' && (
        <div className="space-y-4">
          {/* Big score card */}
          <div className="card gradient-brand text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-4xl font-bold">{profile.healthScore}</div>
                <div className="text-lg opacity-80">/ 100</div>
                <div className="mt-2 text-sm font-semibold" style={{ color: '#9FE1CB' }}>
                  {healthLabel} Business Health
                </div>
                <p className="text-xs opacity-70 mt-1 max-w-xs">
                  Your Business Health Score reflects how well your retail operations are running.
                  A score above 75 qualifies you for working capital loans.
                </p>
              </div>
              <div className="w-28 h-28 relative flex-shrink-0">
                <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="#9FE1CB" strokeWidth="3"
                    strokeDasharray={`${profile.healthScore} ${100 - profile.healthScore}`}
                    strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Zap size={24} style={{ color: '#9FE1CB' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Factor breakdown */}
          <div className="card">
            <h3 className="font-bold text-gray-900 mb-4">Score Breakdown</h3>
            <div className="space-y-4">
              {healthFactors.map(f => (
                <div key={f.label}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{f.label}</span>
                    <span className="text-sm font-bold" style={{
                      color: f.score >= 75 ? '#1D9E75' : f.score >= 50 ? '#BA7517' : '#D85A30'
                    }}>{f.score}/100</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mb-1">
                    <div className="h-2 rounded-full transition-all duration-700"
                      style={{
                        width: `${f.score}%`,
                        background: f.score >= 75 ? '#1D9E75' : f.score >= 50 ? '#BA7517' : '#D85A30'
                      }} />
                  </div>
                  <p className="text-xs text-gray-400">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Credit eligibility */}
          <div className="card" style={{ border: profile.healthScore >= 65 ? '1.5px solid #9FE1CB' : '1px solid #e5e7eb' }}>
            <div className="flex items-center gap-3 mb-3">
              <CreditCard size={18} style={{ color: profile.healthScore >= 65 ? '#1D9E75' : '#9ca3af' }} />
              <h3 className="font-bold text-gray-900">Working Capital Credit</h3>
              {profile.healthScore >= 65
                ? <span className="badge-green">Eligible</span>
                : <span className="badge-gray">Not yet eligible</span>}
            </div>
            {profile.healthScore >= 65 ? (
              <div className="space-y-2">
                <p className="text-sm text-gray-600">
                  Your Business Health Score qualifies you for a working capital loan through our banking partners.
                </p>
                <div className="grid grid-cols-3 gap-3 mt-3">
                  {[
                    { label: 'Min Loan', value: 'GHS 500' },
                    { label: 'Max Loan', value: 'GHS 5,000' },
                    { label: 'Rate', value: '~15% p.a.' },
                  ].map(({ label, value }) => (
                    <div key={label} className="rounded-xl p-3 text-center" style={{ background: '#E1F5EE' }}>
                      <div className="font-bold text-sm" style={{ color: '#1D9E75' }}>{value}</div>
                      <div className="text-xs text-gray-500">{label}</div>
                    </div>
                  ))}
                </div>
                <button className="btn-primary w-full justify-center mt-3">
                  <CreditCard size={15} /> Apply for Credit
                </button>
              </div>
            ) : (
              <p className="text-sm text-gray-500">
                Reach a Business Health Score of 65+ to unlock working capital loans.
                Current score: {profile.healthScore}/100.
                Keep recording daily sales and maintaining stock levels to improve your score.
              </p>
            )}
          </div>
        </div>
      )}

      {/* Data tab */}
      {activeTab === 'data' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="font-bold text-gray-900 mb-1">About RetailIQ</h3>
            <p className="text-sm text-gray-500 mb-4">
              RetailIQ is an Adwuma Pa intelligence platform built for Ghanaian retail businesses.
              All data is stored locally in your browser for privacy.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Version', value: '1.0.0' },
                { label: 'Build', value: 'April 2026' },
                { label: 'Powered by', value: 'CAS Analytics' },
                { label: 'Storage', value: 'LocalStorage' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between text-sm py-2 border-b border-gray-50">
                  <span className="text-gray-500">{label}</span>
                  <span className="font-medium text-gray-900">{value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card" style={{ border: '1px solid #FAECE7' }}>
            <h3 className="font-bold text-gray-900 mb-1">Reset Application Data</h3>
            <p className="text-sm text-gray-500 mb-4">
              This will clear all your sales, inventory, customers, and other data.
              This action cannot be undone.
            </p>
            <button onClick={handleReset} className="btn-danger">
              <RefreshCw size={14} /> Reset All Data
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
