import React from 'react';
import { Bell, AlertTriangle, TrendingUp, Award, CreditCard, CheckCheck, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Alert } from '../types';

const iconMap = {
  stock: AlertTriangle,
  payment: CreditCard,
  insight: TrendingUp,
  achievement: Award,
};

const colorMap: Record<Alert['severity'], { bg: string; text: string; border: string }> = {
  danger:  { bg: '#FAECE7', text: '#993C1D', border: '#F0997B' },
  warning: { bg: '#FAEEDA', text: '#854F0B', border: '#FAC775' },
  info:    { bg: '#E6F1FB', text: '#185FA5', border: '#85B7EB' },
  success: { bg: '#E1F5EE', text: '#0F6E56', border: '#5DCAA5' },
};

export default function Alerts() {
  const { alerts, markAlertRead, markAllAlertsRead, unreadAlerts } = useApp();

  const unread = alerts.filter(a => !a.read);
  const read = alerts.filter(a => a.read);

  const AlertCard = ({ alert }: { alert: Alert }) => {
    const Icon = iconMap[alert.type];
    const colors = colorMap[alert.severity];
    return (
      <div
        className={`rounded-2xl p-4 flex items-start gap-4 transition-all duration-200 ${alert.read ? 'opacity-60' : ''}`}
        style={{ background: colors.bg, border: `1px solid ${colors.border}` }}
      >
        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `${colors.border}55` }}>
          <Icon size={18} style={{ color: colors.text }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="font-semibold text-sm" style={{ color: colors.text }}>{alert.title}</div>
            <span className="text-xs text-gray-400 flex-shrink-0">{alert.date}</span>
          </div>
          <p className="text-sm mt-1 leading-relaxed" style={{ color: colors.text, opacity: 0.85 }}>
            {alert.message}
          </p>
        </div>
        {!alert.read && (
          <button
            onClick={() => markAlertRead(alert.id)}
            className="flex-shrink-0 p-1.5 rounded-lg hover:bg-white/50 transition-colors"
            title="Mark as read"
          >
            <X size={14} style={{ color: colors.text }} />
          </button>
        )}
      </div>
    );
  };

  return (
    <div className="p-4 lg:p-6 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: '#E6F1FB' }}>
            <Bell size={18} style={{ color: '#185FA5' }} />
          </div>
          <div>
            <h2 className="font-bold text-gray-900 text-lg">Notifications</h2>
            <p className="text-xs text-gray-500">{unreadAlerts} unread alerts</p>
          </div>
        </div>
        {unreadAlerts > 0 && (
          <button
            onClick={markAllAlertsRead}
            className="btn-secondary py-2 text-sm"
          >
            <CheckCheck size={14} /> Mark all read
          </button>
        )}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Stock Alerts', count: alerts.filter(a=>a.type==='stock').length, color: '#D85A30', bg: '#FAECE7' },
          { label: 'Insights', count: alerts.filter(a=>a.type==='insight').length, color: '#185FA5', bg: '#E6F1FB' },
          { label: 'Achievements', count: alerts.filter(a=>a.type==='achievement').length, color: '#854F0B', bg: '#FAEEDA' },
          { label: 'Payment Alerts', count: alerts.filter(a=>a.type==='payment').length, color: '#1D9E75', bg: '#E1F5EE' },
        ].map(({ label, count, color, bg }) => (
          <div key={label} className="card p-4 text-center">
            <div className="text-2xl font-bold" style={{ color }}>{count}</div>
            <div className="text-xs text-gray-500 mt-1">{label}</div>
          </div>
        ))}
      </div>

      {/* Unread */}
      {unread.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-700 text-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
            Unread ({unread.length})
          </h3>
          {unread.map(a => <AlertCard key={a.id} alert={a} />)}
        </div>
      )}

      {/* Read */}
      {read.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-500 text-sm">Earlier</h3>
          {read.map(a => <AlertCard key={a.id} alert={a} />)}
        </div>
      )}

      {alerts.length === 0 && (
        <div className="card text-center py-20">
          <Bell size={40} className="mx-auto mb-3 text-gray-300" />
          <p className="text-gray-500">You're all caught up! No alerts.</p>
        </div>
      )}
    </div>
  );
}
