export interface Sale {
  id: string;
  date: string;
  product: string;
  category: string;
  qty: number;
  unitPrice: number;
  total: number;
  paymentMethod: 'cash' | 'momo' | 'card' | 'credit';
  customer?: string;
}

export interface Expense {
  id: string;
  date: string;
  description: string;
  category: string;
  amount: number;
  receipt?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  sku: string;
  qty: number;
  reorderLevel: number;
  costPrice: number;
  sellingPrice: number;
  supplier?: string;
  lastRestocked?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  phone: string;
  email?: string;
  category: string;
  status: 'active' | 'inactive';
  totalOrders: number;
  rating: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  totalPurchases: number;
  lastVisit: string;
  loyaltyPoints: number;
  status: 'active' | 'vip' | 'inactive';
}

export interface BusinessProfile {
  name: string;
  owner: string;
  phone: string;
  email: string;
  location: string;
  businessType: string;
  registrationNumber?: string;
  currency: string;
  healthScore: number;
}

export interface Alert {
  id: string;
  type: 'stock' | 'payment' | 'insight' | 'achievement';
  title: string;
  message: string;
  date: string;
  read: boolean;
  severity: 'info' | 'warning' | 'danger' | 'success';
}
